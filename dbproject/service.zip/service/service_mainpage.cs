﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TOUROPERATOR_INTERFACE;

namespace dbproject
{
    public partial class service_mainpage : Form
    {
        string connectionString = "Data Source=DESKTOP-842J4RM\\SQLEXPRESS;Initial Catalog=travelease;Integrated Security=True;Encrypt=False";
        private int _providerID;

        public service_mainpage(int providerID)
        {
            InitializeComponent();
            _providerID = providerID;

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox15_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox18_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Transport reg = new Transport(_providerID);
            reg.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Food reg = new Food(_providerID);
            reg.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Hotel reg = new Hotel(_providerID);
            reg.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            guide reg = new guide(_providerID);
            reg.Show();
            this.Hide();
        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT * FROM AssignedServices WHERE ServiceProviderID = @providerid";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@providerid", _providerID);

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int serviceId = -1;
                serviceId = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["AssignedServiceID"].Value);

                if (serviceId == -1)
                {
                    MessageBox.Show("Please select a service to accept.");
                    return;
                }


                int providerId1 = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["ServiceProviderID"].Value);

                MessageBox.Show($"Selected ProviderID: {providerId1}\nLogged-in ProviderID: {_providerID}");


                if (providerId1 != _providerID)
                {
                    MessageBox.Show("You can not update services provided by other serviceproviders.");
                    return;
                }

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "UPDATE AssignedServices SET ServiceProviderStatus = 'Available' WHERE AssignedServiceID = @ServiceID";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@ServiceID", serviceId);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Status updated to Available.");
                }
            }
        }



        private void button10_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {

                int serviceId = -1;
                serviceId = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["AssignedServiceID"].Value);

                if (serviceId == -1)
                {
                    MessageBox.Show("Please select a service to accept.");
                    return;
                }

                int providerId2 = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["ServiceProviderID"].Value);


                if (providerId2 != _providerID)
                {
                    MessageBox.Show("You can not update services provided by other serviceproviders.");
                    return;
                }

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "UPDATE AssignedServices SET ServiceProviderStatus = 'NotAvailable' WHERE AssignedServiceID = @ServiceID";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@ServiceID", serviceId);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Status updated to Available.");
                }
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            home hm = new home();
            hm.Show();
            this.Hide();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            home hm = new home();
            hm.Show();
            this.Hide();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            home hm = new home();
            hm.Show();
            this.Hide();
        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }
    }
}
